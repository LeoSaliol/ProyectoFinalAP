package com.leonel.Leonel.Saliol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeonelSaliolApplicationTests {

	@Test
	void contextLoads() {
	}

}

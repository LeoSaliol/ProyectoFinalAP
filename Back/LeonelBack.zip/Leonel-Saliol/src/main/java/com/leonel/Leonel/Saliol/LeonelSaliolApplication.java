package com.leonel.Leonel.Saliol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeonelSaliolApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeonelSaliolApplication.class, args);
	}

}
